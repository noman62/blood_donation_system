from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from .models import BloodDonor
from .forms import BloodDonorForm

def home(request):
    total_donors = BloodDonor.objects.count()
    blood_group_counts = {}
    for group, _ in BloodDonor.BLOOD_GROUPS:
        blood_group_counts[group] = BloodDonor.objects.filter(bloodgroup=group).count()
    
    context = {
        'total_donors': total_donors,
        'blood_group_counts': blood_group_counts
    }
    return render(request, 'home.html', context)

def add_donor(request):
    if request.method == 'POST':
        form = BloodDonorForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Donor added successfully!')
            return redirect('donor_list')
    else:
        form = BloodDonorForm()
    return render(request, 'add_donor.html', {'form': form})

def donor_list(request):
    donors = BloodDonor.objects.all()
    return render(request, 'donor_list.html', {'donors': donors})

