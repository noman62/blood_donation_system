from django.contrib import admin
from .models import BloodDonor

@admin.register(BloodDonor)
class BloodDonorAdmin(admin.ModelAdmin):
    list_display = ('name', 'number', 'bloodgroup', 'donationdate')
    list_filter = ('bloodgroup', 'donationdate')
    search_fields = ('name', 'number')
